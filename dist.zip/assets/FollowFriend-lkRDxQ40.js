import{_ as e,c,o}from"./index-ADD4d3-n.js";const n={};function r(t,s){return o(),c("div",null," 关注 ")}const a=e(n,[["render",r]]);export{a as default};
