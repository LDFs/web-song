import{a as e,c as a,o as c}from"./index-3owFkH47.js";const l={__name:"MyMusic",setup(o){return console.log("---",e.value),(t,n)=>(c(),a("div",null," 我的音乐 "))}};export{l as default};
